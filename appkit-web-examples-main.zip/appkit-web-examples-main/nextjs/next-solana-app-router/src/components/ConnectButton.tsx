'use client'

export const ConnectButton = () => {

  return (
    <div >
        <appkit-button />
    </div>
  )
}
