# Reown Smart Session Example using wagmi with smart sessions(Vite + React)

## Usage

1. Clone the repository
2. Run `pnpm install` to install dependencies
3. Run `pnpm run dev` to start the development server

4. run `cd server`
5. run `pnpm install` to install dependencies
6. run `pnpm start` to start the server

## Resources

- [Reown — Docs](https://docs.reown.com)
- [Vite — GitHub](https://github.com/vitejs/vite)
- [Vite — Docs](https://vitejs.dev/guide/)
